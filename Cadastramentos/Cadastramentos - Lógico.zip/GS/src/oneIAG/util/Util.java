package oneIAG.util;

import java.util.ArrayList;

import static javax.swing.JOptionPane.*;
import static java.lang.Integer.parseInt;

import oneIAG.cadastrar.Cadastrar;
import oneIAG.cadastrarcliente.cadastrarCliente;
import oneIAG.cadastrardoacao.cadastrarDoacao;

public class Util {
	
	ArrayList<Cadastrar> lista = new ArrayList<Cadastrar>();
	
	public void menu() {
		try {
			int opcao;
			
			do {
				opcao = parseInt(showInputDialog(gerarMenu()));
				
				if(opcao < 1 || opcao > 5) {
					showMessageDialog(null, "Valor Inválido");
				}
				
				switch(opcao) {
				case 1:
					inserir(opcao);
					break;
				case 2:
					pesquisar();
					break;
				case 3:
					alterar();
					break;
				case 4:
					remover();
					break;
				}
			}while(opcao != 5);
			
		}catch (NumberFormatException e) {
			showMessageDialog(null, "Não coloque algo que não seja número");
		}
	}
	
	
	private void remover() {
		String email;
		boolean encontrado = false;
		
		 if(lista.isEmpty()) {
			 showMessageDialog(null, "Não existe nenhum email");
		 }
		 else {
			 listar();
			 email = showInputDialog(listar() + "Email");
			 			 
			 for (int i = 0; i < lista.size(); i++) {
				 
				 Cadastrar cadastrar = lista.get(i);
				 
				 if(email.equals(cadastrar.getEmail())) {
					encontrado = true;
					lista.remove(i);
				 }
				 
			 }
			 
			 if(encontrado == false) {
				 showMessageDialog(null, "Não foi encontrado nenhum usuário com esse email");
			 }
			 
		 }
		
	}


	private void alterar() {
		String nome, email, cpf, numeroTelefone, tipoSemente, tipoAgricultura;
		boolean encontrado = false;
		
		 if(lista.isEmpty()) {
			 showMessageDialog(null, "Não existe nenhum email");
		 }
		 else {
			 listar();
			 email = showInputDialog(listar() + "Email");
			 			 
			 for (int i = 0; i < lista.size(); i++) {
				 
				 Cadastrar cadastrar = lista.get(i);
				 
				 if(email.equals(cadastrar.getEmail())) {
					encontrado = true;
					
					nome = showInputDialog("Novo nome");
					email = showInputDialog("Novo email");
					cpf = showInputDialog("Novo CPF");
					numeroTelefone = showInputDialog("Novo número de telefone");
					 
					 if(lista.get(i) instanceof cadastrarCliente) {
						 lista.remove(i);
						 tipoAgricultura = showInputDialog("Novo Tipo de Agricultura: (ex: moderna, intensiva, extensiva, familiar, etc.)");
						 lista.add(new cadastrarCliente(nome, email, cpf, numeroTelefone, tipoAgricultura));
						 break;
					 }
					 else {
						 lista.remove(i);
						 tipoSemente = showInputDialog("Novo Tipo de Semente");
						 lista.add(new cadastrarDoacao(nome, email, cpf, numeroTelefone, tipoSemente));	
						 break;
					 }
				 }
				 
			 }
			 
			 if(encontrado == false) {
				 showMessageDialog(null, "Não foi encontrado nenhum usuário com esse email");
			 }
			 
		 }
		 
		
	}


	private void pesquisar() {
		 String email;
		 boolean encontrado = false;
		 
		 if(lista.isEmpty()) {
			 showMessageDialog(null, "Não existe nenhum email");
		 }
		 else {
			 
			 email = showInputDialog("Email");
			 			 
			 for (int i = 0; i < lista.size(); i++) {
				 
				 Cadastrar inscricao = lista.get(i);
				 
				 if(email.equals(inscricao.getEmail())) {
					 showMessageDialog(null, inscricao.toString());
					 encontrado = true;
				 }
				 
			 }
			 
			 if(encontrado == false) {
				 showMessageDialog(null, "Não foi encontrado nenhum usuário com esse email");
			 }
			 
		 }
		
	}


	private void inserir(int opcao) {
		String nome, email, cpf, numeroTelefone, tipoSemente, tipoAgricultura;
		
		do {
			
			opcao = parseInt(showInputDialog("1. Cadastrar Cliente" + "\n" + "2. Cadastrar Doação"));
			if(opcao < 1 || opcao > 2) {
				showMessageDialog(null, "Opcao Invalida");
			}	
			
			
			switch(opcao) {
			case 1:
			case 2:
				nome = showInputDialog("Nome");
				email = showInputDialog("Email");
				cpf = showInputDialog("CPF");
				numeroTelefone = showInputDialog("Número de Telefone");
				
				if(opcao == 1) {
					tipoAgricultura = showInputDialog("Tipo de Agricultura: (ex: moderna, intensiva, extensiva, familiar, etc.)");
					lista.add(new cadastrarCliente(nome, email, cpf, numeroTelefone, tipoAgricultura));
				}
				else {
					tipoSemente = showInputDialog("Tipo de Semente");
					lista.add(new cadastrarDoacao(nome, email, cpf, numeroTelefone, tipoSemente));	
				}
				break;
			}
			
		}while(opcao < 1 || opcao > 2);
	}
	
	private String listar() {
		String aux = "";
		for (int i = 0; i < lista.size(); i++) {
			aux += "Cadastro " + (i+1) + ":\n";
			aux += lista.get(i).toString() + "\n\n";
		}
		return aux;
	}

	private String gerarMenu() {
		String aux = "";
		aux += "1. Cadastrar" + "\n";
		aux += "2. Pesquisar" + "\n";
		aux += "3. Alteração" + "\n";
		aux += "4. Remoção" + "\n";
		aux += "5. Finalizar" + "\n";
		return aux;
	}
	
}
