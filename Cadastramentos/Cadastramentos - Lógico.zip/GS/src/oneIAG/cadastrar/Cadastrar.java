package oneIAG.cadastrar;

public abstract class Cadastrar {
	
	protected String nome;
	protected String email;
	protected String cpf;
	protected String numeroTelefone;
	
	public Cadastrar(String nome, String email, String cpf, String numeroTelefone) {
		this.nome = nome;
		this.email = email;
		this.cpf = cpf;
		this.numeroTelefone = numeroTelefone;
	}

	@Override
	public String toString() {
		return "Inscricao [nome=" + nome + ", email=" + email + ", cpf=" + cpf + ", numeroTelefone=" + numeroTelefone
				+ "]";
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNumeroTelefone() {
		return numeroTelefone;
	}

	public void setNumeroTelefone(String numeroTelefone) {
		this.numeroTelefone = numeroTelefone;
	}

	
	
}
