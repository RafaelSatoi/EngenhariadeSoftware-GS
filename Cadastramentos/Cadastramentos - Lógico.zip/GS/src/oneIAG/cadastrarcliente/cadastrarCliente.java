package oneIAG.cadastrarcliente;

import oneIAG.cadastrar.Cadastrar;

public class cadastrarCliente extends Cadastrar{
	
	private String tipoAgricultura;

	public cadastrarCliente(String nome, String email, String cpf, String numeroTelefone, String tipoAgricultura) {
		super(nome, email, cpf, numeroTelefone);
		this.tipoAgricultura = tipoAgricultura;
		
	}

	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "Email: " + email + "\n";
		aux += "CPF: " + cpf + "\n";
		aux += "Numero de Telefone: " + numeroTelefone + "\n";
		aux += "Tipo de Agricultura: " + tipoAgricultura;
		return aux;
	}
	

}
