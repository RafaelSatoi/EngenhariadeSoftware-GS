package oneIAG.main;

import oneIAG.util.Util;

public class Main {

	public static void main(String[] args) {
		
		new Util().menu();
		
	}

}
