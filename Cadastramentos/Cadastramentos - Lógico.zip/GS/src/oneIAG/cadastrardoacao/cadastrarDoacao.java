package oneIAG.cadastrardoacao;

import oneIAG.cadastrar.Cadastrar;

public class cadastrarDoacao extends Cadastrar{
	
	private String tipoSemente;

	public cadastrarDoacao(String nome, String email, String cpf, String numeroTelefone, String tipoSemente) {
		super(nome, email, cpf, numeroTelefone);
		this.tipoSemente = tipoSemente;
	}

	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + nome + "\n";
		aux += "Email: " + email + "\n";
		aux += "CPF: " + cpf + "\n";
		aux += "Numero de Telefone: " + numeroTelefone + "\n";
		aux += "Tipo de Semente: " + tipoSemente;
		
		return aux;
	}

	public String getTipoSemente() {
		return tipoSemente;
	}

	public void setTipoSemente(String tipoSemente) {
		this.tipoSemente = tipoSemente;
	}


}
